mymean <-function (x=0,y=0)
{
  output = (x+y)/2
  output
}

